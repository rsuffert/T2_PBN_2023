
NOME DO JOGO: Whac-A-Mole.

DESCRIÇÃO: há 5 buracos. O jogo irá sortear uma posição de onde sairá uma "fuinha", que permanecerá fora de sua toca por um curto período de tempo. O jogador deve, então, selecionar, utilizando as teclas W, A, S, D e X, qual o buraco de onde a "fuinha" saiu (as teclas são pensadas para representar de forma intuitiva a disposição dos buracos no visor LCD). Se ele acertar o buraco antes da "fuinha" desaparecer (ou seja, conseguir dar um "hit" na fuinha), o contador de pontos é incrementado; se ele errar, nada acontece. O jogo termina após um determinado período de tempo, e o objetivo é acertar a maior quantidade de "fuinhas" antes do tempo acabar.

RECURSOS EMPREGADOS:
	5 botões, representando as teclas W, A, S, D e X, utilizados para indicar qual o buraco em que o jogador deseja desferir o seu golpe;
	1 LCD, representando o visor do jogo;
	1 timer, utilizado para indicar a duração do jogo. Um determinado número de interrupções geradas por ele indica que o tempo se esgotou e, portanto, o jogo acabou.